package com.example.ghessekhane

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private data class Story(
    val id: Long, val title: String, val category: String, val summary: String,
    val body: String, val locked: Boolean, val price: String, val favorite: Boolean = false,
    val cover: String = ""
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { GhesseApp() } }
}

@Composable
private fun GhesseApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("ghesse_local", Context.MODE_PRIVATE) }
    var stories by remember { mutableStateOf(loadStories(prefs)) }
    var categories by remember { mutableStateOf(loadCategories(prefs)) }
    var appTitle by remember { mutableStateOf(prefs.getString("appTitle", "قصه‌خانه") ?: "قصه‌خانه") }
    var subtitle by remember { mutableStateOf(prefs.getString("subtitle", "دنیایی از قصه‌های خواندنی") ?: "دنیایی از قصه‌های خواندنی") }
    var adminPin by remember { mutableStateOf(prefs.getString("pin", "1234") ?: "1234") }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", false)) }
    var accent by remember { mutableIntStateOf(prefs.getInt("accent", 0xFF9A6847.toInt())) }
    var query by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("همه") }
    var page by remember { mutableStateOf("home") }
    var selectedStory by remember { mutableStateOf<Story?>(null) }
    var editing by remember { mutableStateOf<Story?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var showAdminLogin by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showCategoryDialog by remember { mutableStateOf(false) }
    var newCategory by remember { mutableStateOf("") }
    var loginPin by remember { mutableStateOf("") }
    var loginError by remember { mutableStateOf(false) }
    var readerSize by remember { mutableIntStateOf(18) }
    var unlockedIds by remember { mutableStateOf(prefs.getStringSet("unlocked", emptySet())?.toSet() ?: emptySet()) }

    fun saveAll() {
        prefs.edit().putString("stories", encodeStories(stories)).putString("categories", JSONArray(categories).toString())
            .putString("appTitle", appTitle).putString("subtitle", subtitle).putString("pin", adminPin)
            .putBoolean("dark", dark).putInt("accent", accent).putStringSet("unlocked", unlockedIds).apply()
    }
    LaunchedEffect(stories, categories, appTitle, subtitle, adminPin, dark, accent, unlockedIds) { saveAll() }

    val bg = if (dark) Color(0xFF171513) else Color(0xFFF7F1E8)
    val surface = if (dark) Color(0xFF26211D) else Color(0xFFFFFCF7)
    val ink = if (dark) Color(0xFFF6EDE2) else Color(0xFF30251E)
    val primary = Color(accent)
    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = primary, background = bg, surface = surface) else lightColorScheme(primary = primary, background = bg, surface = surface)) {
        Scaffold(containerColor = bg, bottomBar = {
            NavigationBar(containerColor = surface) {
                NavigationBarItem(selected = page == "home", onClick = { page = "home" }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("خانه") })
                NavigationBarItem(selected = page == "favorites", onClick = { page = "favorites" }, icon = { Icon(Icons.Default.Favorite, null) }, label = { Text("علاقه‌مندی") })
                NavigationBarItem(selected = page == "categories", onClick = { page = "categories" }, icon = { Icon(Icons.Default.Category, null) }, label = { Text("دسته‌ها") })
                NavigationBarItem(selected = page == "admin", onClick = { showAdminLogin = true }, icon = { Icon(Icons.Default.AdminPanelSettings, null) }, label = { Text("مدیریت") })
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                if (selectedStory != null) {
                    ReaderScreen(story = selectedStory!!, unlocked = !selectedStory!!.locked || unlockedIds.contains(selectedStory!!.id.toString()), ink = ink, surface = surface, readerSize = readerSize,
                        onBack = { selectedStory = null }, onUnlock = {
                            // Demo unlock only. Replace with verified Cafe Bazaar billing before public sale.
                            unlockedIds = unlockedIds + selectedStory!!.id.toString()
                        }, onFavorite = { s -> stories = stories.map { if (it.id == s.id) it.copy(favorite = !it.favorite) else it } }, onSize = { readerSize = it })
                } else when (page) {
                    "home" -> HomeScreen(appTitle, subtitle, stories, categories, query, { query = it }, selectedCategory, { selectedCategory = it }, ink, surface, primary,
                        onStory = { selectedStory = it }, onSettings = { showSettings = true })
                    "favorites" -> StoryListScreen("داستان‌های موردعلاقه", stories.filter { it.favorite }, ink, surface, onStory = { selectedStory = it })
                    "categories" -> CategoryScreen(categories, stories, ink, surface, onSelect = { selectedCategory = it; page = "home" }, onAdd = { showCategoryDialog = true })
                    "admin" -> AdminScreen(stories, ink, surface, onAdd = { editing = null; showEditor = true }, onEdit = { editing = it; showEditor = true }, onDelete = { s -> stories = stories.filterNot { it.id == s.id }; unlockedIds = unlockedIds - s.id.toString() }, onSettings = { showSettings = true })
                }
            }
        }

        if (showAdminLogin) AlertDialog(onDismissRequest = { showAdminLogin = false; loginPin = "" }, title = { Text("ورود مدیر") }, text = {
            Column { Text("رمز مدیریت را وارد کنید") ; Spacer(Modifier.height(8.dp)); OutlinedTextField(loginPin, { loginPin = it; loginError = false }, label = { Text("رمز عبور") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true); if (loginError) Text("رمز اشتباه است", color = MaterialTheme.colorScheme.error) }
        }, confirmButton = { TextButton(onClick = { if (loginPin == adminPin) { showAdminLogin = false; page = "admin" } else loginError = true }) { Text("ورود") } }, dismissButton = { TextButton(onClick = { showAdminLogin = false }) { Text("انصراف") } })

        if (showEditor) StoryEditor(editing, categories, onDismiss = { showEditor = false }, onSave = { s -> stories = if (editing == null) stories + s.copy(id = System.currentTimeMillis()) else stories.map { if (it.id == s.id) s else it }; showEditor = false })
        if (showSettings) SettingsDialog(appTitle, subtitle, adminPin, dark, accent, onDismiss = { showSettings = false }, onSave = { t, sub, pin, d, a -> appTitle = t; subtitle = sub; adminPin = pin; dark = d; accent = a; showSettings = false })
        if (showCategoryDialog) AlertDialog(onDismissRequest = { showCategoryDialog = false }, title = { Text("افزودن دسته‌بندی") }, text = { OutlinedTextField(newCategory, { newCategory = it }, label = { Text("نام دسته‌بندی") }) }, confirmButton = { TextButton(onClick = { if (newCategory.isNotBlank() && newCategory !in categories) categories = categories + newCategory.trim(); newCategory = ""; showCategoryDialog = false }) { Text("افزودن") } }, dismissButton = { TextButton(onClick = { showCategoryDialog = false }) { Text("لغو") } })
    }
}

@Composable private fun HomeScreen(title: String, subtitle: String, stories: List<Story>, categories: List<String>, query: String, onQuery: (String)->Unit, category: String, onCategory: (String)->Unit, ink: Color, surface: Color, primary: Color, onStory: (Story)->Unit, onSettings: ()->Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = ink); Text(subtitle, color = ink.copy(alpha = .65f), fontSize = 13.sp) }
            IconButton(onClick = onSettings) { Icon(Icons.Default.Palette, "تنظیمات ظاهر", tint = primary) }
        }
        OutlinedTextField(query, onQuery, Modifier.fillMaxWidth(), placeholder = { Text("جست‌وجوی داستان، عنوان یا موضوع...") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(16.dp))
        Spacer(Modifier.height(14.dp))
        androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterChip(selected = category == "همه", onClick = { onCategory("همه") }, label = { Text("همه") }) }
            items(categories) { c -> FilterChip(selected = category == c, onClick = { onCategory(c) }, label = { Text(c) }) }
        }
        Spacer(Modifier.height(12.dp))
        Text("داستان‌های تازه", color = ink, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        val filtered = stories.filter { (category == "همه" || it.category == category) && (query.isBlank() || it.title.contains(query, true) || it.body.contains(query, true) || it.category.contains(query, true)) }
        if (filtered.isEmpty()) EmptyState("داستانی پیدا نشد", "از بخش مدیریت داستان تازه اضافه کن", ink)
        else LazyColumn(contentPadding = PaddingValues(bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { items(filtered, key = { it.id }) { StoryCard(it, ink, surface, primary, onStory) } }
    }
}

@Composable private fun StoryCard(s: Story, ink: Color, surface: Color, primary: Color, onClick: (Story)->Unit) {
    Card(Modifier.fillMaxWidth().clickable { onClick(s) }, colors = CardDefaults.cardColors(containerColor = surface), shape = RoundedCornerShape(18.dp), elevation = CardDefaults.cardElevation(1.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(62.dp).clip(RoundedCornerShape(14.dp)).background(primary.copy(alpha = .13f)), contentAlignment = Alignment.Center) { Icon(if (s.locked) Icons.Default.Lock else Icons.Default.MenuBook, null, tint = primary, modifier = Modifier.size(30.dp)) }
            Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(s.title, color = ink, fontWeight = FontWeight.Bold, fontSize = 16.sp); Text(s.category, color = primary, fontSize = 12.sp); Spacer(Modifier.height(4.dp)); Text(s.summary, color = ink.copy(alpha = .7f), maxLines = 2, fontSize = 12.sp) }
            if (s.locked) Icon(Icons.Default.Lock, null, tint = primary)
        }
    }
}

@Composable private fun StoryListScreen(title: String, stories: List<Story>, ink: Color, surface: Color, onStory: (Story)->Unit) { Column(Modifier.fillMaxSize()) { Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = ink, modifier = Modifier.padding(vertical = 18.dp)); if (stories.isEmpty()) EmptyState("هنوز داستانی ذخیره نکرده‌ای", "با لمس قلب کنار داستان‌ها آن‌ها را اینجا ببین", ink) else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(stories) { StoryCard(it, ink, surface, MaterialTheme.colorScheme.primary, onStory) } } } }

@Composable private fun CategoryScreen(categories: List<String>, stories: List<Story>, ink: Color, surface: Color, onSelect: (String)->Unit, onAdd: ()->Unit) { Column(Modifier.fillMaxSize()) { Row(Modifier.fillMaxWidth().padding(vertical = 18.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text("دسته‌بندی داستان‌ها", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = ink); IconButton(onClick = onAdd) { Icon(Icons.Default.Add, "افزودن دسته") } }; LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(categories) { c -> Card(Modifier.fillMaxWidth().clickable { onSelect(c) }, colors = CardDefaults.cardColors(containerColor = surface)) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.AutoStories, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(12.dp)); Text(c, Modifier.weight(1f), color = ink, fontWeight = FontWeight.Medium); Text("${stories.count { it.category == c }} داستان", color = ink.copy(alpha = .6f), fontSize = 12.sp); Icon(Icons.Default.ChevronLeft, null) } } } } } }

@Composable private fun AdminScreen(stories: List<Story>, ink: Color, surface: Color, onAdd: ()->Unit, onEdit: (Story)->Unit, onDelete: (Story)->Unit, onSettings: ()->Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Column { Text("پنل مدیریت", color = ink, fontSize = 24.sp, fontWeight = FontWeight.Bold); Text("${stories.size} داستان ثبت شده", color = ink.copy(alpha = .65f), fontSize = 12.sp) }; IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, null) } }
        Button(onClick = onAdd, Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("افزودن داستان جدید") }
        Spacer(Modifier.height(12.dp)); Text("مدیریت محتوا", color = ink, fontWeight = FontWeight.Bold)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) { items(stories, key = { it.id }) { s -> Card(colors = CardDefaults.cardColors(containerColor = surface), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(s.title, color = ink, fontWeight = FontWeight.Bold); Text("${s.category} • ${if (s.locked) "قفل‌شده" else "رایگان"}", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp) }; IconButton(onClick = { onEdit(s) }) { Icon(Icons.Default.Edit, "ویرایش") }; IconButton(onClick = { onDelete(s) }) { Icon(Icons.Default.Delete, "حذف", tint = MaterialTheme.colorScheme.error) } } } } }
    }
}

@Composable private fun ReaderScreen(story: Story, unlocked: Boolean, ink: Color, surface: Color, readerSize: Int, onBack: ()->Unit, onUnlock: ()->Unit, onFavorite: (Story)->Unit, onSize: (Int)->Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowForward, "بازگشت", tint = ink) }; Text(story.title, Modifier.weight(1f), color = ink, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1); IconButton(onClick = { onFavorite(story) }) { Icon(Icons.Default.FavoriteBorder, "علاقه‌مندی", tint = MaterialTheme.colorScheme.primary) } }
        if (!unlocked) {
            Spacer(Modifier.height(70.dp)); Icon(Icons.Default.Lock, null, Modifier.align(Alignment.CenterHorizontally).size(54.dp), tint = MaterialTheme.colorScheme.primary); Text("این داستان ویژه است", Modifier.fillMaxWidth().padding(top = 16.dp), textAlign = TextAlign.Center, color = ink, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("برای خواندن این داستان باید آن را خریداری کنی.", Modifier.fillMaxWidth().padding(12.dp), textAlign = TextAlign.Center, color = ink.copy(alpha = .7f)); Button(onClick = onUnlock, Modifier.fillMaxWidth()) { Text("باز کردن آزمایشی داستان • ${story.price}") }; Text("این دکمه فقط برای آزمایش قفل است و پرداخت واقعی انجام نمی‌دهد.", Modifier.padding(12.dp), color = ink.copy(alpha = .6f), fontSize = 11.sp, textAlign = TextAlign.Center)
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) { Text("اندازه متن", color = ink, fontSize = 12.sp); IconButton(onClick = { onSize((readerSize - 1).coerceAtLeast(14)) }) { Icon(Icons.Default.Remove, null) }; Text("$readerSize", color = ink); IconButton(onClick = { onSize((readerSize + 1).coerceAtMost(30)) }) { Icon(Icons.Default.Add, null) } }
            Text(story.category, color = MaterialTheme.colorScheme.primary, fontSize = 12.sp); Text(story.title, color = ink, fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp, bottom = 16.dp))
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) { item { Text(story.body, color = ink, fontSize = readerSize.sp, lineHeight = (readerSize * 1.85).sp) } }
        }
    }
}

@Composable private fun StoryEditor(existing: Story?, categories: List<String>, onDismiss: ()->Unit, onSave: (Story)->Unit) {
    var title by remember { mutableStateOf(existing?.title ?: "") }; var category by remember { mutableStateOf(existing?.category ?: categories.firstOrNull().orEmpty()) }; var summary by remember { mutableStateOf(existing?.summary ?: "") }; var body by remember { mutableStateOf(existing?.body ?: "") }; var locked by remember { mutableStateOf(existing?.locked ?: false) }; var price by remember { mutableStateOf(existing?.price ?: "۱۹,۰۰۰ تومان") }; var expanded by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "داستان جدید" else "ویرایش داستان") }, text = {
        Column(Modifier.heightIn(max = 520.dp)) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { OutlinedTextField(title, { title = it }, label = { Text("عنوان داستان") }, modifier = Modifier.fillMaxWidth()) }
                item { Box { OutlinedButton(onClick = { expanded = true }, Modifier.fillMaxWidth()) { Text("دسته‌بندی: $category") }; DropdownMenu(expanded, { expanded = false }) { categories.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { category = it; expanded = false }) } } } }
                item { OutlinedTextField(summary, { summary = it }, label = { Text("خلاصه کوتاه") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(body, { body = it }, label = { Text("متن کامل داستان") }, modifier = Modifier.fillMaxWidth().height(180.dp), minLines = 5) }
                item { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(locked, { locked = it }); Text("داستان قفل‌دار / پولی") } }
                if (locked) item { OutlinedTextField(price, { price = it }, label = { Text("قیمت نمایشی") }, modifier = Modifier.fillMaxWidth()) }
            }
        }
    }, confirmButton = { TextButton(enabled = title.isNotBlank() && body.isNotBlank(), onClick = { onSave(Story(existing?.id ?: 0L, title.trim(), category, summary, body, locked, price, existing?.favorite ?: false, existing?.cover ?: "")) }) { Text("ذخیره") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } })
}

@Composable private fun SettingsDialog(title0: String, subtitle0: String, pin0: String, dark0: Boolean, accent0: Int, onDismiss: ()->Unit, onSave: (String,String,String,Boolean,Int)->Unit) {
    var title by remember { mutableStateOf(title0) }; var subtitle by remember { mutableStateOf(subtitle0) }; var pin by remember { mutableStateOf(pin0) }; var dark by remember { mutableStateOf(dark0) }; var accent by remember { mutableIntStateOf(accent0) }
    val colors = listOf(0xFF9A6847.toInt(), 0xFF294B65.toInt(), 0xFF557A46.toInt(), 0xFF7C466C.toInt(), 0xFFB17A2B.toInt())
    AlertDialog(onDismissRequest = onDismiss, title = { Text("تنظیمات و هویت برنامه") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(title, { title = it }, label = { Text("نام نمایشی برنامه") }); OutlinedTextField(subtitle, { subtitle = it }, label = { Text("شعار صفحه اصلی") }); OutlinedTextField(pin, { pin = it }, label = { Text("رمز مدیریت") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)); Row(verticalAlignment = Alignment.CenterVertically) { Text("حالت شب", Modifier.weight(1f)); Switch(dark, { dark = it }) }; Text("رنگ اصلی"); Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { colors.forEach { c -> Box(Modifier.size(34.dp).clip(RoundedCornerShape(50)).background(Color(c)).clickable { accent = c }, contentAlignment = Alignment.Center) { if (accent == c) Icon(Icons.Default.Check, null, tint = Color.White) } } }; Text("نام نمایشی و رنگ داخل برنامه تغییر می‌کند. تغییر نام زیر آیکون گوشی به ساخت نسخه جدید نیاز دارد.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f)) } }, confirmButton = { TextButton(onClick = { onSave(title.ifBlank { "قصه‌خانه" }, subtitle, pin.ifBlank { "1234" }, dark, accent) }) { Text("ذخیره تغییرات") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } })
}

@Composable private fun EmptyState(title: String, desc: String, ink: Color) { Column(Modifier.fillMaxWidth().padding(top = 55.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.AutoStories, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = .7f)); Spacer(Modifier.height(12.dp)); Text(title, color = ink, fontWeight = FontWeight.Bold); Text(desc, color = ink.copy(alpha = .6f), fontSize = 12.sp) } }

private fun loadCategories(p: android.content.SharedPreferences): List<String> { val raw = p.getString("categories", null) ?: return listOf("اخلاقی و پندآموز", "تاریخی", "عاشقانه", "معمایی", "ترسناک", "طنز", "ماجراجویی", "کودکانه"); return try { val a = JSONArray(raw); (0 until a.length()).map { a.getString(it) } } catch (_: Exception) { listOf("اخلاقی و پندآموز", "تاریخی", "عاشقانه", "معمایی", "ترسناک", "طنز", "ماجراجویی", "کودکانه") } }
private fun loadStories(p: android.content.SharedPreferences): List<Story> { val raw = p.getString("stories", null); if (raw != null) return decodeStories(raw); return listOf(Story(1, "چراغی در دل تاریکی", "اخلاقی و پندآموز", "داستانی کوتاه درباره امید و مهربانی", "در روستایی دورافتاده، پیرمردی هر شب چراغ کوچکی پشت پنجره می‌گذاشت. شبی جوانی از او پرسید: چرا وقتی کسی از این راه عبور نمی‌کند، چراغ را روشن می‌کنی؟ پیرمرد لبخند زد و گفت: شاید امشب کسی راه خانه‌اش را گم کرده باشد.\n\nسال‌ها گذشت و یک شب طوفانی، همان جوان که اکنون مردی میانسال شده بود، در تاریکی راه را گم کرد. از دور نوری دید و به سوی آن رفت. چراغ پیرمرد هنوز روشن بود.\n\nآن شب فهمید مهربانی همیشه برای کسی است که شاید روزی به آن نیاز پیدا کند؛ حتی اگر ندانیم چه کسی خواهد بود.", false, "رایگان"), Story(2, "راز عمارت خاموش", "معمایی", "یک داستان آزمایشی قفل‌شده برای بررسی خرید", "این داستان نمونه قفل‌شده است. برای آزمایش، دکمه باز کردن آزمایشی را بزنید. پس از باز شدن، متن کامل داستان در این قسمت نمایش داده می‌شود.\n\nنیمه‌شب، نامه‌ای بی‌نام زیر در عمارت افتاد. روی آن فقط یک جمله نوشته شده بود: حقیقت در اتاقی پنهان است که هیچ‌کس واردش نمی‌شود...", true, "۱۵,۰۰۰ تومان")) }
private fun encodeStories(stories: List<Story>): String { val a = JSONArray(); stories.forEach { s -> a.put(JSONObject().put("id", s.id).put("title", s.title).put("category", s.category).put("summary", s.summary).put("body", s.body).put("locked", s.locked).put("price", s.price).put("favorite", s.favorite).put("cover", s.cover)) }; return a.toString() }
private fun decodeStories(raw: String): List<Story> = try { val a = JSONArray(raw); (0 until a.length()).map { val o = a.getJSONObject(it); Story(o.optLong("id"), o.optString("title"), o.optString("category"), o.optString("summary"), o.optString("body"), o.optBoolean("locked"), o.optString("price"), o.optBoolean("favorite"), o.optString("cover")) } } catch (_: Exception) { emptyList() }
